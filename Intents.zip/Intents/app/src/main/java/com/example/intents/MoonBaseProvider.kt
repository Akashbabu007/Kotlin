package com.example.intents

import android.net.Uri

object MoonBaseProvider {
    val CONTENT_URI: Uri = Uri.parse("content://moonbases")
}