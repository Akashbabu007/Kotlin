package com.example.views

class Season {
    fun valueOf(season: Season?): String {
        return "January"
    }
}
